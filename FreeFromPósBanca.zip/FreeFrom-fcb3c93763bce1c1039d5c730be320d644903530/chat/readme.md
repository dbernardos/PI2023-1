- para poder acessar a aplicação na sua maquina:

```bash
  npm install
```

```bash
  npm run dev
```

- Depois acessar a url que vai mostrar no console
