exports.page = (req, res) => {
    res.render('_404');
}