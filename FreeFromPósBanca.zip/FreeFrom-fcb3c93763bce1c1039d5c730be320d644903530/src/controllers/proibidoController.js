exports.page = (req, res) => {
    res.render('_proibido', {error: "Nada de errado ksks"});
}